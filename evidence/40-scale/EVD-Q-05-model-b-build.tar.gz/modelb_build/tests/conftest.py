import json
import os
import sys
import time
from pathlib import Path

import jwt
import pytest
from fastapi.testclient import TestClient

BUILD = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BUILD))

from app.config import Settings  # noqa: E402
from app.main import create_app  # noqa: E402

SECRET = "test-secret-0123456789abcdef0123456789"


def make_token(role="dispatcher", sub="user-1", tenant="default", exp_in=300, secret=SECRET, extra=None):
    claims = {"sub": sub, "role": role, "tenant": tenant, "exp": int(time.time()) + exp_in}
    claims.update(extra or {})
    return jwt.encode(claims, secret, algorithm="HS256")


def auth(role="dispatcher", **kw):
    return {"Authorization": f"Bearer {make_token(role, **kw)}"}


def make_settings(tmp_path, rate=30, data_dir=None):
    return Settings(
        app_env="local", auth_mode="hs256", auth_secret=SECRET,
        data_dir=Path(data_dir) if data_dir else BUILD / "data",
        semantic_layer_dir=BUILD / "semantic-layer",
        audit_path=tmp_path / "audit.jsonl", approvals_path=tmp_path / "approvals.jsonl",
        ai_rate_per_minute=rate,
    )


@pytest.fixture
def settings(tmp_path):
    return make_settings(tmp_path)


@pytest.fixture
def client(settings):
    return TestClient(create_app(settings))


@pytest.fixture
def audit_lines(settings):
    def read():
        path = settings.audit_path
        if not path.exists():
            return []
        return [json.loads(x) for x in path.read_text().splitlines() if x.strip()]
    return read
