import time

import pytest

from app.config import ConfigError, load_settings
from tests.conftest import SECRET, auth, make_settings, make_token, BUILD
from fastapi.testclient import TestClient
from app.main import create_app

KEY = "SHI-00002"


def test_health_and_ready(client):
    assert client.get("/health").json() == {"status": "ok"}
    r = client.get("/ready")
    assert r.status_code == 200 and r.json()["checks"]["data"] is True


def test_ready_503_when_curated_layer_missing_health_still_ok(tmp_path):
    client = TestClient(create_app(make_settings(tmp_path, data_dir=tmp_path / "nowhere")))
    assert client.get("/health").status_code == 200
    r = client.get("/ready")
    assert r.status_code == 503
    assert r.headers["content-type"].startswith("application/problem+json")


def test_lookup_exact_key_and_masking_for_dispatcher(client):
    r = client.get(f"/records/{KEY}", headers=auth("dispatcher"))
    assert r.status_code == 200
    body = r.json()
    assert body["shipment_id"] == KEY
    assert body["customer_id"] == "***"          # dispatcher: customer_id mask
    assert body["data_quality_flags"]            # rows with flags are returned, not dropped


def test_customer_support_sees_customer_but_warehouse_loses_it(client):
    cs = client.get(f"/records/{KEY}", headers=auth("customer_support", ), params={"purpose": "customer_support"})
    assert cs.status_code == 200 and cs.json()["customer_id"] == "CUS-00002"
    wh = client.get(f"/records/{KEY}", headers=auth("warehouse_ops"))
    assert wh.status_code == 200 and "customer_id" not in wh.json()


def test_absent_key_is_404_and_bad_shape_is_422(client):
    assert client.get("/records/SHI-99999", headers=auth()).status_code == 404
    r = client.get("/records/REC-0001", headers=auth())
    assert r.status_code == 422


def test_no_token_and_forged_role_header_are_401(client):
    assert client.get(f"/records/{KEY}").status_code == 401
    r = client.get(f"/records/{KEY}", headers={"X-User-Role": "admin"})
    assert r.status_code == 401
    assert r.headers["www-authenticate"] == "Bearer"


def test_bad_signature_expired_and_unknown_persona(client):
    bad = {"Authorization": "Bearer " + make_token(secret="x" * 40)}
    assert client.get(f"/records/{KEY}", headers=bad).status_code == 401
    expired = {"Authorization": "Bearer " + make_token(exp_in=-600)}
    assert client.get(f"/records/{KEY}", headers=expired).status_code == 401
    r = client.get(f"/records/{KEY}", headers=auth("root_admin"))
    assert r.status_code == 403 and r.json()["status"] == 403


def test_wrong_purpose_is_403_with_audit(client, audit_lines):
    r = client.get(f"/records/{KEY}", headers=auth("dispatcher"), params={"purpose": "customs_clearance"})
    assert r.status_code == 403
    last = audit_lines()[-1]
    assert last["policy_decision"]["decision"] == "deny"
    assert last["policy_decision"]["rule"].startswith("access-semantics:dispatcher/shipments")
    assert last["action"] == "record.read"


def test_correlation_id_echoed_and_audited(client, audit_lines):
    cid = "abcd1234-test-corr"
    r = client.get(f"/records/{KEY}", headers={**auth(), "X-Correlation-ID": cid})
    assert r.headers["x-correlation-id"] == cid
    assert audit_lines()[-1]["correlation_id"] == cid
    r2 = client.get("/health", headers={"X-Correlation-ID": "bad id!"})
    assert len(r2.headers["x-correlation-id"]) >= 8 and r2.headers["x-correlation-id"] != "bad id!"


def test_audit_chain_verifies_and_detects_tampering(client, settings, audit_lines):
    client.get(f"/records/{KEY}", headers=auth())
    client.get("/records/SHI-00003", headers=auth("warehouse_ops"))
    v = client.get("/audit/verify", headers=auth("auditor"))
    assert v.json()["valid"] is True and v.json()["records"] >= 2
    assert client.get("/audit/verify", headers=auth("dispatcher")).status_code == 403
    lines = settings.audit_path.read_text().splitlines()
    lines[0] = lines[0].replace('"outcome":"success"', '"outcome":"denied"')
    settings.audit_path.write_text("\n".join(lines) + "\n")
    v = client.get("/audit/verify", headers=auth("auditor")).json()
    assert v == {"valid": False, "records": len(lines), "first_bad_index": 0}


def test_summary_http_body_validates_against_schema(client):
    import json, jsonschema
    from app.ai import OUTPUT_SCHEMA
    r = client.post(f"/ai/summarize/{KEY}", headers=auth("ai_agent"))
    assert r.status_code == 200
    body = r.json()
    jsonschema.validate(body, OUTPUT_SCHEMA)
    assert body["generated_by"] == "deterministic" and body["model_version"] and body["prompt_version"]
    assert body["token_estimate"] > 0 and body["source_count"] == len(body["sources"]) >= 2
    assert body["requires_human_approval"] is True and body["guardrail_status"] == "enforced"
    assert "CUS-" not in json.dumps(body)


def test_summary_forbidden_for_human_personas_by_purpose(client):
    assert client.post(f"/ai/summarize/{KEY}", headers=auth("dispatcher")).status_code == 403


def test_approval_is_recorded_once_and_second_decision_is_409(client, audit_lines):
    sid = client.post(f"/ai/summarize/{KEY}", headers=auth("ai_agent")).json()["summary_id"]
    r = client.post(f"/ai/summaries/{sid}/decision", headers=auth("dispatcher"),
                    json={"decision": "approve", "reason": "ok"})
    assert r.status_code == 200
    approval_id = r.json()["approval_id"]
    assert audit_lines()[-1]["approval_id"] == approval_id
    again = client.post(f"/ai/summaries/{sid}/decision", headers=auth("dispatcher"), json={"decision": "reject"})
    assert again.status_code == 409
    assert client.post(f"/ai/summaries/{sid}/decision", headers=auth("ai_agent"),
                       json={"decision": "approve"}).status_code == 403
    assert client.post(f"/ai/summaries/{sid}/decision", headers=auth("dispatcher"),
                       json={"decision": "maybe"}).status_code == 422
    assert client.post("/ai/summaries/sum_missing/decision", headers=auth("dispatcher"),
                       json={"decision": "approve"}).status_code == 404


def test_ai_rate_limit_returns_429(tmp_path):
    client = TestClient(create_app(make_settings(tmp_path, rate=2)))
    statuses = [client.post(f"/ai/summarize/{KEY}", headers=auth("ai_agent", sub="svc")).status_code
                for _ in range(3)]
    assert statuses == [200, 200, 429]


def test_start_refused_outside_local_without_secret(monkeypatch):
    with pytest.raises(ConfigError):
        load_settings({"APP_ENV": "staging"})
    with pytest.raises(ConfigError):
        load_settings({"AUTH_SECRET": "too-short"})
    s = load_settings({"APP_ENV": "local", "AUTH_SECRET": SECRET})
    assert s.ai_rate_per_minute == 30
