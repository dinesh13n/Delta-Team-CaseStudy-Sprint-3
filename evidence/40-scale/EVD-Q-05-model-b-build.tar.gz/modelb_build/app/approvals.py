"""Suggestion and human-decision records (JSON Lines, replayed at start-up)."""
from __future__ import annotations

import json
import threading
import uuid
from pathlib import Path

from app.audit import canonical_json, utc_now_iso


class ApprovalError(RuntimeError):
    pass


class AlreadyDecided(Exception):
    pass


class ApprovalStore:
    def __init__(self, path: Path):
        self._path = Path(path)
        self._lock = threading.Lock()
        self._suggestions: dict[str, dict] = {}
        self._decisions: dict[str, dict] = {}
        self._load()

    def _load(self) -> None:
        if not self._path.exists():
            return
        for line in self._path.read_text(encoding="utf-8").splitlines():
            if not line.strip():
                continue
            rec = json.loads(line)
            if rec.get("kind") == "suggestion":
                self._suggestions[rec["summary_id"]] = rec
            elif rec.get("kind") == "decision":
                self._decisions[rec["summary_id"]] = rec

    def _write(self, rec: dict) -> None:
        try:
            self._path.parent.mkdir(parents=True, exist_ok=True)
            with self._path.open("a", encoding="utf-8") as fh:
                fh.write(canonical_json(rec) + "\n")
                fh.flush()
        except OSError as exc:
            raise ApprovalError("approval write failed") from exc

    def add_suggestion(self, rec: dict) -> None:
        with self._lock:
            entry = {"kind": "suggestion", **rec}
            self._write(entry)
            self._suggestions[rec["summary_id"]] = entry

    def get_suggestion(self, summary_id: str) -> dict | None:
        return self._suggestions.get(summary_id)

    def lock(self) -> threading.Lock:
        return self._lock

    def status(self, summary_id: str) -> str:
        decision = self._decisions.get(summary_id)
        return decision["decision"] if decision else "suggested"

    def decide(self, summary_id: str, decision: str, decided_by: str, reason: str | None,
               approval_id: str | None = None) -> dict:
        """Caller must hold lock(). Raises AlreadyDecided on a second decision."""
        if summary_id in self._decisions:
            raise AlreadyDecided(summary_id)
        rec = {
            "kind": "decision",
            "approval_id": approval_id or str(uuid.uuid4()),
            "summary_id": summary_id,
            "decision": decision,
            "decided_by": decided_by,
            "decided_at": utc_now_iso(),
            "reason": reason or "",
        }
        self._write(rec)
        self._decisions[summary_id] = rec
        return rec
