"""Bearer token verification (HS256 for this build; JWKS is a fail-closed stub)."""
from __future__ import annotations

from dataclasses import dataclass

import jwt

from app.config import Settings

# Personas from semantic-layer/access-semantics.yaml plus the two platform roles
# named in the implementation PRD (ops, auditor). Only personas get data access.
PERSONAS = frozenset({
    "dispatcher", "warehouse_ops", "fleet_manager", "driver", "customs_agent",
    "customer_support", "carrier_partner", "ai_agent",
})
PLATFORM_ROLES = frozenset({"ops", "auditor"})
KNOWN_ROLES = PERSONAS | PLATFORM_ROLES
CLOCK_SKEW_SECONDS = 60


class TokenError(Exception):
    pass


@dataclass(frozen=True)
class Principal:
    subject: str
    role: str
    tenant: str


def verify_token(token: str, settings: Settings) -> Principal:
    if settings.auth_mode != "hs256":
        # JWKS verifier is specified (ADR-0004) but not built: fail closed.
        raise TokenError("token verifier not configured")
    try:
        claims = jwt.decode(
            token,
            settings.auth_secret,
            algorithms=["HS256"],
            leeway=CLOCK_SKEW_SECONDS,
            options={"require": ["exp", "sub", "role", "tenant"]},
        )
    except jwt.PyJWTError as exc:
        raise TokenError("invalid token") from exc
    subject, role, tenant = claims.get("sub"), claims.get("role"), claims.get("tenant")
    if not all(isinstance(v, str) and v.strip() for v in (subject, role, tenant)):
        raise TokenError("invalid token claims")
    return Principal(subject=subject, role=role, tenant=tenant)


def bearer_token(authorization: str | None) -> str | None:
    if not authorization:
        return None
    scheme, _, value = authorization.partition(" ")
    if scheme.lower() != "bearer" or not value.strip():
        return None
    return value.strip()
