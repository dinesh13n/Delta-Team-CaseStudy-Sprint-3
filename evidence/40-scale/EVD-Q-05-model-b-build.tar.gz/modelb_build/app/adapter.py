"""Harness adapter: runs the same gateway as POST /ai/summarize/{id}, without HTTP.

summarize_case(case, provider=None) -> the same JSON object the endpoint returns in its body.
provider=None uses the built-in deterministic provider.
"""
from __future__ import annotations

import os
import uuid
from pathlib import Path

from app.ai import run_summary
from app.config import BUILD_DIR
from app.policy import Policy

_POLICY_CACHE: dict[str, Policy] = {}


def _policy() -> Policy:
    directory = Path(os.environ.get("SEMANTIC_LAYER_DIR") or BUILD_DIR / "semantic-layer")
    key = str(directory.resolve())
    if key not in _POLICY_CACHE:
        _POLICY_CACHE[key] = Policy.load(directory)
    return _POLICY_CACHE[key]


def summarize_case(case: dict, provider=None) -> dict:
    if not isinstance(case, dict):
        raise TypeError("case must be a dict")
    shipment = case.get("shipment")
    events = case.get("events") or []
    bookings = case.get("bookings") or []
    if not isinstance(shipment, dict):
        raise TypeError("case['shipment'] must be a dict")
    if not isinstance(events, list) or not all(isinstance(e, dict) for e in events):
        raise TypeError("case['events'] must be a list of dicts")
    if not isinstance(bookings, list) or not all(isinstance(b, dict) for b in bookings):
        raise TypeError("case['bookings'] must be a list of dicts")
    return run_summary(
        shipment={k: "" if v is None else str(v) for k, v in shipment.items()},
        events=[{k: "" if v is None else str(v) for k, v in e.items()} for e in events],
        bookings=[{k: "" if v is None else str(v) for k, v in b.items()} for b in bookings],
        policy=_policy(),
        correlation_id=uuid.uuid4().hex,
        provider=provider,
    )
