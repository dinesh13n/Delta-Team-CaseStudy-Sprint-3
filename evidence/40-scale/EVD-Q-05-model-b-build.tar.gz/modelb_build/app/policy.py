"""Persona x entity x field x purpose decisions driven by access-semantics.yaml.

Deny by default. The scope dimension is recorded but not enforced: the curated
data carries no hub, fleet or customer-ownership attribute (IA-6 in the PRD).
"""
from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path

import yaml

ACCESS_LEVELS = {"read": {"read", "write"}, "write": {"write"}}
ENFORCEABLE_SCOPES = {"all", "all active"}


@dataclass(frozen=True)
class Decision:
    allowed: bool
    rule: str
    scope_enforced: bool = True
    reason: str = ""


@dataclass
class Policy:
    access: dict
    ai_context: dict
    sensitive_fields: set = field(default_factory=set)
    status_domains: dict = field(default_factory=dict)

    @classmethod
    def load(cls, semantic_dir: Path) -> "Policy":
        access = yaml.safe_load((semantic_dir / "access-semantics.yaml").read_text(encoding="utf-8"))
        ai_ctx = yaml.safe_load((semantic_dir / "ai-context-policy.yaml").read_text(encoding="utf-8"))
        taxonomy = yaml.safe_load((semantic_dir / "status-taxonomy.yaml").read_text(encoding="utf-8"))
        if not isinstance(access, dict) or "personas" not in access:
            raise ValueError("access-semantics.yaml has no personas")
        domains = {name: set(spec["values"]) for name, spec in taxonomy["enums"].items()}
        return cls(
            access=access,
            ai_context=ai_ctx,
            sensitive_fields=set(access.get("sensitive_fields", [])),
            status_domains=domains,
        )

    # -- entity level -------------------------------------------------------
    def persona_entry(self, persona: str, entity: str) -> dict | None:
        spec = self.access["personas"].get(persona)
        if not spec:
            return None
        return spec.get(entity)

    def decide(self, persona: str, entity: str, action: str, purpose: str | None) -> Decision:
        rule = f"access-semantics:{persona}/{entity}/{action}"
        if persona not in self.access["personas"]:
            return Decision(False, "persona.unknown", reason="unknown persona")
        entry = self.persona_entry(persona, entity)
        if not entry:
            return Decision(False, rule, reason="entity not declared for persona")
        if entry.get("access") not in ACCESS_LEVELS[action]:
            return Decision(False, rule, reason=f"access {entry.get('access')} does not allow {action}")
        if not purpose or purpose not in (entry.get("purposes") or []):
            return Decision(False, rule, reason="purpose not allowed")
        scope = str(entry.get("scope", ""))
        return Decision(True, rule, scope_enforced=scope in ENFORCEABLE_SCOPES, reason="")

    def default_purpose(self, persona: str, entity: str) -> str | None:
        entry = self.persona_entry(persona, entity) or {}
        purposes = entry.get("purposes") or []
        return purposes[0] if purposes else None

    # -- field level --------------------------------------------------------
    def field_mode(self, persona: str, entity: str, fld: str) -> str:
        """Return 'allow', 'mask' or 'deny'. Sensitive fields default to mask."""
        entry = self.persona_entry(persona, entity) or {}
        overrides = entry.get("field_overrides") or {}
        if fld in overrides:
            return overrides[fld]
        if f"{entity}.{fld}" in self.sensitive_fields or fld in self.sensitive_fields:
            return "mask"
        return "allow"

    # -- AI context ---------------------------------------------------------
    def ai_field_visible(self, entity: str, fld: str) -> bool:
        allowed = (self.ai_context.get("allowed_fields") or {}).get(entity, [])
        if fld not in allowed:
            return False
        if f"{entity}.{fld}" in (self.ai_context.get("forbidden_fields") or []):
            return False
        return self.field_mode("ai_agent", entity, fld) == "allow"

    def domain(self, name: str) -> set:
        return self.status_domains.get(name, set())
