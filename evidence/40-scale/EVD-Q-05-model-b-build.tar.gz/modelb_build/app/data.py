"""Read-only curated data layer (CSV adapter behind a repository port)."""
from __future__ import annotations

import csv
import threading
from pathlib import Path

CURATED_FILES = {
    "shipments": "shipments.csv",
    "tracking_events": "tracking_events.csv",
    "carrier_bookings": "carrier_bookings.csv",
}


class DataUnavailable(RuntimeError):
    pass


class CuratedRepository:
    """Loads the curated CSVs once. A failed load is not cached, so it is retried."""

    def __init__(self, data_dir: Path):
        self._dir = Path(data_dir) / "curated"
        self._lock = threading.Lock()
        self._tables: dict[str, list[dict]] | None = None
        self._by_key: dict[str, dict] = {}
        self._events: dict[str, list[dict]] = {}
        self._bookings: dict[str, list[dict]] = {}

    def _load(self) -> None:
        tables: dict[str, list[dict]] = {}
        for name, filename in CURATED_FILES.items():
            path = self._dir / filename
            try:
                with path.open(newline="", encoding="utf-8") as fh:
                    tables[name] = list(csv.DictReader(fh))
            except (OSError, csv.Error, UnicodeDecodeError) as exc:
                raise DataUnavailable(f"curated file unreadable: {filename}") from exc
        by_key: dict[str, dict] = {}
        for row in tables["shipments"]:
            # Business key is unique (BR-K-shipments); first occurrence wins if not.
            by_key.setdefault(row["shipment_id"], row)
        events: dict[str, list[dict]] = {}
        for row in tables["tracking_events"]:
            events.setdefault(row["shipment_id"], []).append(row)
        bookings: dict[str, list[dict]] = {}
        for row in tables["carrier_bookings"]:
            bookings.setdefault(row["shipment_id"], []).append(row)
        self._tables, self._by_key, self._events, self._bookings = tables, by_key, events, bookings

    def ensure_loaded(self) -> None:
        with self._lock:
            if self._tables is None:
                self._load()

    def ready(self) -> bool:
        try:
            self.ensure_loaded()
            return True
        except DataUnavailable:
            return False

    def get_shipment(self, shipment_id: str) -> dict | None:
        self.ensure_loaded()
        return self._by_key.get(shipment_id)

    def events_for(self, shipment_id: str) -> list[dict]:
        self.ensure_loaded()
        return list(self._events.get(shipment_id, []))

    def bookings_for(self, shipment_id: str) -> list[dict]:
        self.ensure_loaded()
        return list(self._bookings.get(shipment_id, []))
