"""AI exception-summary gateway (FEAT-04, suggest-only, L0).

Shared by POST /ai/summarize/{id} and app.adapter.summarize_case, so both produce the
same body. Model output is untrusted: it must parse, validate against
MODEL_OUTPUT_SCHEMA, pass the output guardrail and clear the confidence floor, or the
deterministic provider is used. The final body is validated against
ai-summary-output.schema.json.
"""
from __future__ import annotations

import hashlib
import json
import math
import re
import unicodedata
import uuid
from collections import Counter
from pathlib import Path

import jsonschema

from app.policy import Policy

CONTRACT_DIR = Path(__file__).resolve().parent / "contract"
PROMPT_VERSION = "exception_summary_v1"
PROMPT_TEXT = (Path(__file__).resolve().parent / "prompts" / "exception_summary_v1.txt").read_text(encoding="utf-8")
PROMPT_SHA = hashlib.sha256(PROMPT_TEXT.encode("utf-8")).hexdigest()
OUTPUT_SCHEMA = json.loads((CONTRACT_DIR / "ai-summary-output.schema.json").read_text(encoding="utf-8"))
_OUTPUT_VALIDATOR = jsonschema.Draft202012Validator(OUTPUT_SCHEMA)

MAX_CONTEXT_TOKENS = 8000       # ai-context-policy.yaml
MAX_RECORD_TOKENS = 2000        # ai-context-policy.yaml
MAX_EVENTS_IN_CONTEXT = 20
MAX_VALUE_CHARS = 200
CONFIDENCE_FLOOR = 0.5          # ASSUMPTION: below this a suggestion is not shown
ACTIVE_EXCLUDED_BOOKING = {"closed", "failed"}   # business-rules BR-05
LEGACY_TOLERATED = {"shipments.status": {"approved"}, "carrier_bookings.status": {"approved"}}
ABSTAIN_REASONS = ("insufficient_context", "low_confidence", "schema_violation", "policy_blocked",
                   "provider_unavailable")

MODEL_OUTPUT_SCHEMA = {
    "type": "object",
    "required": ["summary", "recommendation", "confidence"],
    "additionalProperties": False,
    "properties": {
        "summary": {"type": "string", "maxLength": 1200},
        "recommendation": {"type": "string", "maxLength": 400},
        "confidence": {"type": "number", "minimum": 0, "maximum": 1},
        "abstain_reason": {"enum": [None, *ABSTAIN_REASONS]},
    },
}
_MODEL_VALIDATOR = jsonschema.Draft202012Validator(MODEL_OUTPUT_SCHEMA)

_TEMPLATE_RE = re.compile(r"\{\{|\}\}|\{%|%\}|\$\{|__[a-z]+__|\{[^{}]*\.__", re.I)
_CONTROL_RE = re.compile(r"[\x00-\x1f\x7f]")
_OUTPUT_FORBIDDEN_RE = re.compile(
    r"[<>]|\{\{|\}\}|\{%|%\}|\$\{|__[a-z]+__|"
    r"ignore (?:all )?previous instructions|"
    r"\b(?:executed|auto-?approved|rebooked|cancelled|canceled|dispatched|rerouted)\b",
    re.I,
)
_LEAK_RE = re.compile(r"\b(?:CUS|DRI)-\d+\b")


class PolicyDenied(Exception):
    def __init__(self, rule: str):
        super().__init__(rule)
        self.rule = rule


class GatewayError(RuntimeError):
    """Internal failure (for example, the output does not validate). Maps to 500."""


class SchemaViolation(Exception):
    pass


class _Generator:
    def __init__(self, name: str, version: str):
        self.name, self.version = name, version


DETERMINISTIC = _Generator("deterministic", "1.0.0")
EXTERNAL = _Generator("external-provider", "unknown")


class DeterministicProvider:
    """Default and fallback provider. Builds the summary from validated fields only."""

    def __call__(self, system_prompt: str, data_json: str) -> str:
        ctx = json.loads(data_json)
        s, events, bookings, quality = ctx["shipment"], ctx["events"], ctx["bookings"], ctx["quality"]
        sid = s["shipment_id"]
        status = s.get("status", "")
        sentences = [f"Shipment {sid} is recorded with status '{status}'"]
        if s.get("service_tier"):
            sentences[0] += f" under the '{s['service_tier']}' service tier"
        sentences[0] += "."
        if s.get("promised_at"):
            sentences.append(f"Promised delivery time is {s['promised_at']}.")
        if quality.get("status_legacy"):
            sentences.append("The status value is a legacy value and is flagged for owner review.")
        sentences.append(f"The tracking history holds {len(events)} event(s) in the context.")
        if events:
            last = events[-1]
            if last.get("event_type"):
                sentences.append(f"The latest event is '{last['event_type']}' at {last.get('event_time', 'an unknown time')}.")
            else:
                sentences.append("The latest event type is outside the declared domain.")
        statuses = sorted({b.get("status", "") for b in bookings if b.get("status")})
        sentences.append(f"Carrier bookings: {len(bookings)}" + (f" with status {', '.join(statuses)}." if statuses else "."))
        if any(b.get("compensation_required") is True for b in bookings):
            sentences.append("At least one booking is marked as requiring compensation review.")
        summary = " ".join(sentences)[:1200]

        compensation = any(b.get("compensation_required") is True for b in bookings)
        if status in ("exception", "failed", "manual_hold"):
            recommendation = (f"Refer shipment {sid} to the dispatcher for review of the '{status}' state. "
                              "No action has been taken by the system.")
        elif compensation:
            recommendation = (f"Refer the compensation requirement on shipment {sid} to the dispatcher. "
                              "No action has been taken by the system.")
        elif status == "closed":
            recommendation = f"No action suggested; shipment {sid} is closed."
        else:
            recommendation = f"No action suggested; keep shipment {sid} under monitoring until the promised time."

        penalty = 0.0
        penalty += 0.15 if quality.get("service_tier_invalid") else 0.0
        penalty += 0.10 if quality.get("status_legacy") else 0.0
        penalty += min(0.05 * quality.get("invalid_event_types", 0), 0.30)
        penalty += min(0.05 * quality.get("legacy_booking_status", 0), 0.10)
        confidence = round(max(0.0, min(1.0, 0.9 - penalty)), 3)
        return json.dumps({"summary": summary, "recommendation": recommendation, "confidence": confidence},
                          ensure_ascii=False)


def clean_text(value) -> tuple[str, bool]:
    """Strip control characters; replace template syntax by a marker. Returns (text, removed)."""
    text = "" if value is None else str(value)
    text = _CONTROL_RE.sub(" ", text).strip()
    if _TEMPLATE_RE.search(text):
        return "[removed]", True
    return text[:MAX_VALUE_CHARS], False


def _estimate_tokens(text: str) -> int:
    return math.ceil(len(text) / 4)


def _encode_data(ctx: dict) -> str:
    raw = json.dumps(ctx, sort_keys=True, ensure_ascii=False)
    # Escaped so a value cannot close or open markup in the data block.
    return raw.replace("<", "\\u003c").replace(">", "\\u003e")


def _sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def _valid_or_legacy(policy: Policy, entity: str, field: str, value: str, domain: str) -> tuple[str | None, bool]:
    """Return (value or None, legacy_flag). Out-of-domain values are dropped, not replaced."""
    if value in policy.domain(domain):
        return value, False
    if value in LEGACY_TOLERATED.get(f"{entity}.{field}", set()):
        return value, True
    return None, False


def build_context(*, policy: Policy, shipment: dict, events: list, bookings: list,
                  persona: str, purpose: str, counters: Counter) -> tuple[dict, list, str | None]:
    """Reduce the record to allow-listed, sanitised fields. Returns (context, sources, abstain_reason)."""
    def visible(entity: str, field: str) -> bool:
        return policy.ai_field_visible(entity, field)

    def clean(value) -> str:
        text, removed = clean_text(value)
        if removed:
            counters["template_removed"] += 1
        return text

    quality = {"service_tier_invalid": False, "status_legacy": False,
               "invalid_event_types": 0, "legacy_booking_status": 0}

    shipment_ctx: dict = {}
    sources: list[dict] = []
    sid = clean(shipment.get("shipment_id"))
    if visible("shipments", "shipment_id"):
        shipment_ctx["shipment_id"] = sid
    sources.append({"dataset": "shipments", "record_id": sid})

    status_raw = clean(shipment.get("status"))
    status, legacy = _valid_or_legacy(policy, "shipments", "status", status_raw, "shipment_status")
    if status and visible("shipments", "status"):
        shipment_ctx["status"] = status
        quality["status_legacy"] = legacy
    tier = clean(shipment.get("service_tier"))
    if tier and tier not in policy.domain("service_tier") and visible("shipments", "service_tier"):
        quality["service_tier_invalid"] = True
    elif tier and visible("shipments", "service_tier"):
        shipment_ctx["service_tier"] = tier
    promised = clean(shipment.get("promised_at"))
    if promised and visible("shipments", "promised_at"):
        shipment_ctx["promised_at"] = promised
    for flag in ("customs_required", "temperature_controlled"):
        raw = clean(shipment.get(flag)).lower()
        if raw in ("true", "false") and visible("shipments", flag):
            shipment_ctx[flag] = raw == "true"

    missing = [f for f in ("shipment_id", "status", "promised_at") if not clean(shipment.get(f))]
    if missing or status is None:
        return _ctx(shipment_ctx, [], [], quality), sources, "insufficient_context"

    event_ctx: list[dict] = []
    event_sources: list[dict] = []
    if policy.decide(persona, "tracking_events", "read", purpose).allowed:
        for ev in events:
            item: dict = {}
            etype = clean(ev.get("event_type"))
            if etype and etype in policy.domain("tracking_event_type"):
                if visible("tracking_events", "event_type"):
                    item["event_type"] = etype
            elif etype:
                quality["invalid_event_types"] += 1
            etime = clean(ev.get("event_time"))
            if etime and visible("tracking_events", "event_time"):
                item["event_time"] = etime
            try:
                seq = int(float(ev.get("sequence_no") or ""))
            except ValueError:
                seq = None
            if seq is not None and visible("tracking_events", "sequence_no"):
                item["sequence_no"] = seq
            source = clean(ev.get("source_system"))
            if source in policy.domain("source_system") and visible("tracking_events", "source_system"):
                item["source_system"] = source
            event_ctx.append((seq if seq is not None else 10**9, item))
            event_sources.append({"dataset": "tracking_events", "record_id": clean(ev.get("event_id"))})
    event_ctx.sort(key=lambda pair: pair[0])
    event_items = [item for _, item in event_ctx][-MAX_EVENTS_IN_CONTEXT:]

    booking_ctx: list[dict] = []
    booking_sources: list[dict] = []
    if policy.decide(persona, "carrier_bookings", "read", purpose).allowed:
        for bk in bookings:
            item = {}
            bstatus_raw = clean(bk.get("status"))
            bstatus, blegacy = _valid_or_legacy(policy, "carrier_bookings", "status", bstatus_raw, "shipment_status")
            if bstatus and visible("carrier_bookings", "status"):
                item["status"] = bstatus
            if blegacy:
                quality["legacy_booking_status"] += 1
            try:
                item["retry_count"] = int(float(bk.get("retry_count") or ""))
            except ValueError:
                pass
            comp = clean(bk.get("compensation_required")).lower()
            if comp in ("true", "false"):
                item["compensation_required"] = comp == "true"
            booking_ctx.append(item)
            booking_sources.append({"dataset": "carrier_bookings", "record_id": clean(bk.get("booking_id"))})

    active = [b for b in bookings if clean(b.get("status")) not in ACTIVE_EXCLUDED_BOOKING]
    conflict = len(active) > 1
    if not event_items and not booking_ctx:
        return _ctx(shipment_ctx, [], [], quality), sources, "insufficient_context"

    sources.extend(event_sources[-MAX_EVENTS_IN_CONTEXT:])
    sources.extend(booking_sources)
    context = _ctx(shipment_ctx, event_items, booking_ctx, quality)
    if conflict:
        # Sources conflict (more than one active booking, BR-05): abstain.
        return context, sources, "low_confidence"
    # Keep the prompt inside the context budget: drop the oldest events first.
    while _estimate_tokens(_encode_data(context)) > MAX_CONTEXT_TOKENS and context["events"]:
        context["events"].pop(0)
        counters["events_trimmed"] += 1
    return context, sources, None


def _ctx(shipment_ctx, events, bookings, quality) -> dict:
    return {"shipment": shipment_ctx, "events": events, "bookings": bookings, "quality": quality}


def parse_model_output(raw) -> dict:
    if not isinstance(raw, str):
        raise SchemaViolation("provider returned a non-text value")
    try:
        obj = json.loads(raw)
    except ValueError as exc:
        raise SchemaViolation("provider output is not JSON") from exc
    try:
        _MODEL_VALIDATOR.validate(obj)
    except jsonschema.ValidationError as exc:
        raise SchemaViolation("provider output does not match the output schema") from exc
    if obj.get("abstain_reason") is None and (not obj["summary"].strip() or not obj["recommendation"].strip()):
        raise SchemaViolation("summary and recommendation are required when not abstaining")
    return obj


def output_guardrail_violations(obj: dict, forbidden_values: list[str]) -> list[str]:
    violations = []
    texts = [obj.get("summary") or "", obj.get("recommendation") or ""]
    for text in texts:
        if _OUTPUT_FORBIDDEN_RE.search(text):
            violations.append("forbidden_pattern")
        if _LEAK_RE.search(text):
            violations.append("identifier_leak")
        if any(v and v in text for v in forbidden_values):
            violations.append("forbidden_value")
    return violations


def _config_hash(gen: _Generator) -> str:
    return _sha256_text(f"{PROMPT_SHA}|{gen.name}|{gen.version}|{MAX_RECORD_TOKENS}")


def _assemble(*, correlation_id, gen, summary, recommendation, confidence, abstained, abstain_reason,
              guardrail_status, generated_by, fallback_reason, sources, token_estimate) -> dict:
    body = {
        "summary_id": "sum_" + uuid.uuid4().hex,
        "model": gen.name,
        "model_version": gen.version,
        "prompt_version": PROMPT_VERSION,
        "summary": summary,
        "recommendation": recommendation,
        "abstained": abstained,
        "abstain_reason": abstain_reason,
        "guardrail_status": guardrail_status,
        "generated_by": generated_by,
        "fallback_reason": fallback_reason,
        "source_count": len(sources),
        "token_estimate": token_estimate,
        "requires_human_approval": True,
        "correlation_id": correlation_id,
        "token_source": "estimate",
        "confidence": confidence,
        "sources": sources,
        "config_hash": _config_hash(gen),
    }
    errors = sorted(_OUTPUT_VALIDATOR.iter_errors(body), key=lambda e: list(e.path))
    if errors:
        raise GatewayError("summary output failed schema validation")
    return body


def run_summary(*, shipment: dict, events: list, bookings: list, policy: Policy,
                correlation_id: str, provider=None, persona: str = "ai_agent",
                purpose: str = "exception_summary") -> dict:
    """Run the guardrailed summary. Raises PolicyDenied, or GatewayError on an internal fault."""
    decision = policy.decide(persona, "shipments", "read", purpose)
    if not decision.allowed:
        raise PolicyDenied(decision.rule)

    counters: Counter = Counter()
    context, sources, pre_abstain = build_context(
        policy=policy, shipment=shipment, events=events, bookings=bookings,
        persona=persona, purpose=purpose, counters=counters)
    if pre_abstain:
        # No generation happened, so there is nothing to guard.
        return _assemble(correlation_id=correlation_id, gen=DETERMINISTIC, summary=None, recommendation=None,
                         confidence=None, abstained=True, abstain_reason=pre_abstain,
                         guardrail_status="not_applicable", generated_by="deterministic",
                         fallback_reason=None, sources=sources, token_estimate=0)

    data_json = _encode_data(context)
    token_estimate = _estimate_tokens(PROMPT_TEXT + data_json)
    forbidden_values = [v for v in [shipment.get("customer_id", "")] if v]
    result = None          # (summary, recommendation, confidence)
    gen = DETERMINISTIC
    generated_by = "deterministic"
    fallback_reason = None
    guardrail_status = "enforced"
    abstain_reason = None

    if provider is not None:
        try:
            obj = parse_model_output(provider(PROMPT_TEXT, data_json))
            if obj.get("abstain_reason"):
                abstain_reason = obj["abstain_reason"]
                gen, generated_by = EXTERNAL, "model"
            elif output_guardrail_violations(obj, forbidden_values):
                guardrail_status, fallback_reason = "blocked", "guardrail_blocked"
            elif obj["confidence"] < CONFIDENCE_FLOOR:
                fallback_reason = "low_confidence"
            else:
                result = (obj["summary"], obj["recommendation"], obj["confidence"])
                gen, generated_by = EXTERNAL, "model"
        except ConnectionError:
            fallback_reason = "provider_unavailable"
        except SchemaViolation:
            fallback_reason = "schema_violation"
        except Exception:  # noqa: BLE001 - any provider fault is untrusted and falls back
            fallback_reason = "provider_error"
        if fallback_reason:
            generated_by = "fallback"

    if result is None and abstain_reason is None:
        try:
            obj = parse_model_output(DeterministicProvider()(PROMPT_TEXT, data_json))
        except Exception as exc:  # noqa: BLE001
            raise GatewayError("deterministic provider failed") from exc
        if output_guardrail_violations(obj, forbidden_values):
            raise GatewayError("deterministic output failed the guardrail")
        if obj["confidence"] < CONFIDENCE_FLOOR:
            abstain_reason = "low_confidence"
        else:
            result = (obj["summary"], obj["recommendation"], obj["confidence"])

    if abstain_reason is not None:
        return _assemble(correlation_id=correlation_id, gen=gen, summary=None, recommendation=None,
                         confidence=None, abstained=True, abstain_reason=abstain_reason,
                         guardrail_status=guardrail_status, generated_by=generated_by,
                         fallback_reason=fallback_reason, sources=sources, token_estimate=token_estimate)
    summary, recommendation, confidence = result
    return _assemble(correlation_id=correlation_id, gen=gen, summary=summary, recommendation=recommendation,
                     confidence=confidence, abstained=False, abstain_reason=None,
                     guardrail_status=guardrail_status, generated_by=generated_by,
                     fallback_reason=fallback_reason, sources=sources, token_estimate=token_estimate)


def input_hash(shipment: dict, events: list, bookings: list) -> str:
    raw = json.dumps({"shipment": shipment, "events": events, "bookings": bookings},
                     sort_keys=True, ensure_ascii=False)
    return _sha256_text(raw)
