"""Hash-chained, append-only audit log (JSON Lines).

hash = SHA-256(canonical_json(event without hash) + prev_hash); genesis prev_hash is 64 zeros.
"""
from __future__ import annotations

import hashlib
import json
import os
import threading
import uuid
from datetime import datetime, timezone
from pathlib import Path

GENESIS = "0" * 64


class AuditError(RuntimeError):
    pass


def canonical_json(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False)


def chain_hash(event_without_hash: dict, prev_hash: str) -> str:
    return hashlib.sha256((canonical_json(event_without_hash) + prev_hash).encode("utf-8")).hexdigest()


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


class AuditSink:
    def __init__(self, path: Path):
        self._path = Path(path)
        self._lock = threading.Lock()
        self._head = self._read_head()

    @property
    def path(self) -> Path:
        return self._path

    def _lines(self) -> list[str]:
        if not self._path.exists():
            return []
        with self._path.open(encoding="utf-8") as fh:
            return [line for line in fh.read().split("\n") if line.strip()]

    def _read_head(self) -> str:
        lines = self._lines()
        if not lines:
            return GENESIS
        try:
            return json.loads(lines[-1])["hash"]
        except (ValueError, KeyError, TypeError):
            # A corrupt tail is reported by verify(); new events chain from GENESIS
            # would hide it, so keep the last hash that parses, or GENESIS.
            return GENESIS

    def append(self, event: dict) -> dict:
        """Complete and write one event. Raises AuditError if it cannot be persisted."""
        with self._lock:
            body = dict(event)
            body.setdefault("event_id", str(uuid.uuid4()))
            body.setdefault("ts", utc_now_iso())
            body["prev_hash"] = self._head
            body.pop("hash", None)
            body["hash"] = chain_hash(body, self._head)
            line = canonical_json(body)
            try:
                self._path.parent.mkdir(parents=True, exist_ok=True)
                with self._path.open("a", encoding="utf-8") as fh:
                    fh.write(line + "\n")
                    fh.flush()
                    os.fsync(fh.fileno())
            except OSError as exc:
                raise AuditError("audit write failed") from exc
            self._head = body["hash"]
            return body

    def verify(self) -> dict:
        expected_prev = GENESIS
        lines = self._lines()
        for index, line in enumerate(lines):
            try:
                event = json.loads(line)
                claimed_hash = event["hash"]
                prev = event["prev_hash"]
            except (ValueError, KeyError, TypeError):
                return {"valid": False, "records": len(lines), "first_bad_index": index}
            body = {k: v for k, v in event.items() if k != "hash"}
            if prev != expected_prev or chain_hash(body, prev) != claimed_hash:
                return {"valid": False, "records": len(lines), "first_bad_index": index}
            expected_prev = claimed_hash
        return {"valid": True, "records": len(lines), "first_bad_index": None}
