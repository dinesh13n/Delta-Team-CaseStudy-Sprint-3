"""HTTP surface: GET /health, /ready, /records/{id}, POST /ai/summarize/{id},
POST /ai/summaries/{id}/decision, GET /audit/verify, GET /openapi.json.

Pipeline per protected request: correlation id -> bearer token (401) -> parameter
shape (422) -> policy (403) -> use case (404) -> audit (fail-closed, 503).
"""
from __future__ import annotations

import json
import logging
import os
import re
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path

import yaml
from fastapi import FastAPI, Request
from fastapi.responses import JSONResponse
from starlette.exceptions import HTTPException as StarletteHTTPException

from app import ai
from app.approvals import AlreadyDecided, ApprovalError, ApprovalStore
from app.audit import AuditError, AuditSink
from app.config import Settings, load_settings
from app.data import CuratedRepository, DataUnavailable
from app.policy import Policy
from app.security import Principal, TokenError, bearer_token, verify_token

CONTRACT_DIR = Path(__file__).resolve().parent / "contract"
RECORD_ID_RE = re.compile(r"SHI-[0-9]{5}")
PURPOSE_RE = re.compile(r"[a-z_]{1,40}")
CORRELATION_RE = re.compile(r"[A-Za-z0-9._:\-]{8,128}")
MAX_BODY_BYTES = 64 * 1024
RATE_WINDOW_SECONDS = 60.0
SHIPMENT_FIELDS = ["shipment_id", "customer_id", "origin", "destination", "service_tier",
                   "declared_weight_kg", "actual_weight_kg", "promised_at", "status",
                   "customs_required", "temperature_controlled"]
NUMERIC_FIELDS = {"declared_weight_kg", "actual_weight_kg"}
BOOLEAN_FIELDS = {"customs_required", "temperature_controlled"}

log = logging.getLogger("app.request")


def _configure_logging() -> None:
    if log.handlers:
        return
    handler = logging.StreamHandler(sys.stdout)
    handler.setFormatter(logging.Formatter("%(message)s"))
    log.addHandler(handler)
    log.setLevel(logging.INFO)
    log.propagate = False


def _now_iso() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


class RateLimiter:
    """Sliding one-minute window per subject (AI endpoint, 30/min default [ASM])."""

    def __init__(self, per_minute: int):
        self._limit = per_minute
        self._hits: dict[str, list[float]] = {}
        self._lock = threading.Lock()

    def allow(self, subject: str) -> bool:
        now = time.monotonic()
        with self._lock:
            hits = [t for t in self._hits.get(subject, []) if now - t < RATE_WINDOW_SECONDS]
            if len(hits) >= self._limit:
                self._hits[subject] = hits
                return False
            hits.append(now)
            self._hits[subject] = hits
            return True


class Services:
    def __init__(self, settings: Settings):
        self.settings = settings
        self.repo = CuratedRepository(settings.data_dir)
        self.audit = AuditSink(settings.audit_path)
        self.approvals = ApprovalStore(settings.approvals_path)
        self.rate = RateLimiter(settings.ai_rate_per_minute)
        self._policy: Policy | None = None

    def policy(self) -> Policy | None:
        if self._policy is None:
            try:
                self._policy = Policy.load(self.settings.semantic_layer_dir)
            except (OSError, ValueError, KeyError, TypeError, yaml.YAMLError):
                return None
        return self._policy


def problem(request: Request, status: int, slug: str, title: str, detail: str | None = None,
            headers: dict | None = None) -> JSONResponse:
    cid = getattr(request.state, "correlation_id", None) or uuid.uuid4().hex
    body = {"type": f"urn:logistics:problem:{slug}", "title": title, "status": status,
            "correlation_id": cid}
    if detail:
        body["detail"] = detail
    return JSONResponse(body, status_code=status, headers=headers or {},
                        media_type="application/problem+json")


def create_app(settings: Settings | None = None) -> FastAPI:
    settings = settings or load_settings()
    _configure_logging()
    svc = Services(settings)

    app = FastAPI(title="Logistics Shipment Operations (subset)", version="1.1.0-draft",
                  docs_url=None, redoc_url=None, openapi_url=None)
    app.state.services = svc

    def audit(request: Request, *, action: str, principal: Principal | None, resource_type: str,
              resource_id: str, rule: str, decision: str, outcome: str, model: dict | None = None,
              input_hash: str | None = None, approval_id: str | None = None,
              detail: dict | None = None) -> JSONResponse | None:
        """Write one audit event. Returns a 503 response if the write fails (fail-closed)."""
        event = {
            "action": action,
            "actor": {
                "subject": principal.subject if principal else "anonymous",
                "role": principal.role if principal else "none",
                "auth_method": "jwt" if principal else "anonymous",
            },
            "correlation_id": request.state.correlation_id,
            "tenant": principal.tenant if principal else "default",
            "resource": {"type": resource_type, "id": resource_id or "-"},
            "policy_decision": {"decision": decision, "rule": rule, "decision_id": uuid.uuid4().hex},
            "model": model,
            "input_hash": input_hash,
            "approval_id": approval_id,
            "outcome": outcome,
            "retention_class": "ai_trace" if action.startswith("ai.") else "operational",
            "detail": detail or {},
        }
        try:
            svc.audit.append(event)
        except AuditError:
            return problem(request, 503, "audit-unavailable", "Service unavailable",
                           "the request could not be audited and was refused")
        request.state.actor_role = event["actor"]["role"]
        return None

    def authenticate(request: Request):
        """Returns (principal, error_response)."""
        token = bearer_token(request.headers.get("authorization"))
        principal = None
        if token:
            try:
                principal = verify_token(token, settings)
            except TokenError:
                principal = None
        if principal is None:
            denial = audit(request, action="auth.denied", principal=None, resource_type="request",
                           resource_id=request.url.path, rule="auth.token", decision="deny",
                           outcome="denied", detail={"reason": "missing_or_invalid_token"})
            if denial is not None:
                return None, denial
            return None, problem(request, 401, "unauthorized", "Unauthorized",
                                 "missing, invalid or expired bearer token",
                                 headers={"WWW-Authenticate": "Bearer"})
        request.state.actor_role = principal.role
        return principal, None

    def unavailable(request: Request, detail: str) -> JSONResponse:
        return problem(request, 503, "data-unavailable", "Service unavailable", detail)

    def policy_or_503(request: Request):
        pol = svc.policy()
        if pol is None:
            return None, unavailable(request, "access policy is not loaded")
        return pol, None

    @app.middleware("http")
    async def correlation_and_limits(request: Request, call_next):
        started = time.perf_counter()
        incoming = request.headers.get("x-correlation-id", "")
        cid = incoming if CORRELATION_RE.fullmatch(incoming) else uuid.uuid4().hex
        request.state.correlation_id = cid
        request.state.actor_role = "anonymous"
        length = request.headers.get("content-length", "")
        if length.isdigit() and int(length) > MAX_BODY_BYTES:
            response = problem(request, 413, "payload-too-large", "Payload too large")
        else:
            response = await call_next(request)
        response.headers["X-Correlation-ID"] = cid
        log.info(json.dumps({
            "ts": _now_iso(), "level": "info", "msg": "request", "correlation_id": cid,
            "method": request.method, "route": re.sub(r"SHI-\d{5}", "{id}", request.url.path),
            "status": response.status_code,
            "latency_ms": round((time.perf_counter() - started) * 1000, 2),
            "actor_role": getattr(request.state, "actor_role", "anonymous"),
        }, sort_keys=True))
        return response

    @app.exception_handler(StarletteHTTPException)
    async def http_error(request: Request, exc: StarletteHTTPException):
        titles = {404: ("not-found", "Not found"), 405: ("method-not-allowed", "Method not allowed")}
        slug, title = titles.get(exc.status_code, ("http-error", "Error"))
        return problem(request, exc.status_code, slug, title)

    @app.exception_handler(Exception)
    async def unexpected(request: Request, exc: Exception):
        log.error(json.dumps({"ts": _now_iso(), "level": "error", "msg": "unhandled",
                              "correlation_id": getattr(request.state, "correlation_id", None),
                              "error_type": type(exc).__name__}))
        return problem(request, 500, "internal", "Internal error", "an unexpected error occurred")

    # -- ops ---------------------------------------------------------------
    @app.get("/health")
    async def health():
        return {"status": "ok"}

    @app.get("/ready")
    async def ready(request: Request):
        audit_dir = svc.audit.path.parent
        try:
            audit_dir.mkdir(parents=True, exist_ok=True)
            audit_ok = os.access(audit_dir, os.W_OK)
        except OSError:
            audit_ok = False
        checks = {
            "data": svc.repo.ready(),
            "semantic_layer": svc.policy() is not None,
            "signing_key": len(settings.auth_secret) >= 32,
            "audit_store": audit_ok,
        }
        if all(checks.values()):
            return {"status": "ready", "checks": checks}
        failed = ", ".join(sorted(k for k, v in checks.items() if not v))
        return problem(request, 503, "not-ready", "Not ready", f"failed checks: {failed}")

    @app.get("/openapi.json")
    async def openapi_document():
        return JSONResponse(yaml.safe_load((CONTRACT_DIR / "openapi.yaml").read_text(encoding="utf-8")))

    # -- record lookup (FEAT-01, FEAT-02) -----------------------------------
    @app.get("/records/{record_id}")
    async def get_record(record_id: str, request: Request):
        principal, error = authenticate(request)
        if error is not None:
            return error
        if not RECORD_ID_RE.fullmatch(record_id):
            return problem(request, 422, "invalid-key", "Validation error", "record id must match SHI-[0-9]{5}")
        purpose_param = request.query_params.get("purpose")
        if purpose_param is not None and not PURPOSE_RE.fullmatch(purpose_param):
            return problem(request, 422, "invalid-parameter", "Validation error", "purpose is malformed")
        pol, error = policy_or_503(request)
        if error is not None:
            return error
        purpose = purpose_param or pol.default_purpose(principal.role, "shipments")
        decision = pol.decide(principal.role, "shipments", "read", purpose)
        if not decision.allowed:
            denial = audit(request, action="record.read", principal=principal, resource_type="shipments",
                           resource_id=record_id, rule=decision.rule, decision="deny", outcome="denied",
                           detail={"reason": decision.reason})
            if denial is not None:
                return denial
            return problem(request, 403, "policy-denied", "Forbidden", "access denied by policy")
        try:
            row = svc.repo.get_shipment(record_id)
        except DataUnavailable:
            return unavailable(request, "curated shipment data is unavailable")
        if row is None:
            failure = audit(request, action="record.read", principal=principal, resource_type="shipments",
                            resource_id=record_id, rule=decision.rule, decision="allow", outcome="error",
                            detail={"reason": "not_found"})
            if failure is not None:
                return failure
            return problem(request, 404, "not-found", "Not found", "no shipment with that key")

        body, masked, denied = {}, [], []
        for fld in SHIPMENT_FIELDS:
            mode = pol.field_mode(principal.role, "shipments", fld)
            if mode == "deny":
                denied.append(fld)
                continue
            if mode == "mask":
                masked.append(fld)
                body[fld] = "***"
                continue
            body[fld] = _typed(fld, row.get(fld, ""))
        body["data_quality_flags"] = [f for f in (row.get("data_quality_flags") or "").split(";") if f]
        failure = audit(request, action="record.read", principal=principal, resource_type="shipments",
                        resource_id=record_id, rule=decision.rule, decision="allow", outcome="success",
                        detail={"masked_fields": masked, "denied_fields": denied,
                                "scope_enforced": decision.scope_enforced})
        if failure is not None:
            return failure
        return JSONResponse(body)

    # -- exception summary (FEAT-04) ----------------------------------------
    @app.post("/ai/summarize/{record_id}")
    async def summarize(record_id: str, request: Request):
        principal, error = authenticate(request)
        if error is not None:
            return error
        if not RECORD_ID_RE.fullmatch(record_id):
            return problem(request, 422, "invalid-key", "Validation error", "record id must match SHI-[0-9]{5}")
        pol, error = policy_or_503(request)
        if error is not None:
            return error
        decision = pol.decide(principal.role, "shipments", "read", "exception_summary")
        if not decision.allowed:
            denial = audit(request, action="ai.summarize", principal=principal, resource_type="shipments",
                           resource_id=record_id, rule=decision.rule, decision="deny", outcome="denied")
            if denial is not None:
                return denial
            return problem(request, 403, "policy-denied", "Forbidden", "access denied by policy")
        if not svc.rate.allow(principal.subject):
            limited = audit(request, action="ai.summarize", principal=principal, resource_type="shipments",
                            resource_id=record_id, rule="rate.ai_per_subject", decision="deny",
                            outcome="denied", detail={"reason": "rate_limited"})
            if limited is not None:
                return limited
            return problem(request, 429, "rate-limited", "Too many requests", "AI rate limit reached",
                           headers={"Retry-After": "60"})
        try:
            row = svc.repo.get_shipment(record_id)
            events = svc.repo.events_for(record_id)
            bookings = svc.repo.bookings_for(record_id)
        except DataUnavailable:
            return unavailable(request, "curated shipment data is unavailable")
        if row is None:
            failure = audit(request, action="ai.summarize", principal=principal, resource_type="shipments",
                            resource_id=record_id, rule=decision.rule, decision="allow", outcome="error",
                            detail={"reason": "not_found"})
            if failure is not None:
                return failure
            return problem(request, 404, "not-found", "Not found", "no shipment with that key")
        try:
            body = ai.run_summary(shipment=row, events=events, bookings=bookings, policy=pol,
                                  correlation_id=request.state.correlation_id)
        except ai.PolicyDenied as exc:
            return problem(request, 403, "policy-denied", "Forbidden", str(exc.rule))
        except ai.GatewayError:
            return problem(request, 500, "internal", "Internal error", "the summary could not be produced")
        model = {"name": body["model"], "version": body["model_version"],
                 "prompt_version": body["prompt_version"], "generated_by": body["generated_by"],
                 "config_hash": body["config_hash"]}
        failure = audit(request, action="ai.summarize", principal=principal, resource_type="shipments",
                        resource_id=record_id, rule=decision.rule, decision="allow", outcome="success",
                        model=model, input_hash=ai.input_hash(row, events, bookings),
                        detail={"summary_id": body["summary_id"], "abstained": body["abstained"],
                                "abstain_reason": body["abstain_reason"],
                                "fallback_reason": body["fallback_reason"],
                                "guardrail_status": body["guardrail_status"],
                                "source_count": body["source_count"]})
        if failure is not None:
            return failure
        try:
            svc.approvals.add_suggestion({
                "summary_id": body["summary_id"], "shipment_id": record_id,
                "correlation_id": body["correlation_id"], "abstained": body["abstained"],
                "created_at": _now_iso(), "created_by": principal.subject,
            })
        except ApprovalError:
            return problem(request, 503, "approval-store-unavailable", "Service unavailable",
                           "the suggestion could not be stored")
        return JSONResponse(body)

    @app.post("/ai/summaries/{summary_id}/decision")
    async def decide_summary(summary_id: str, request: Request):
        principal, error = authenticate(request)
        if error is not None:
            return error
        raw = await request.body()
        try:
            payload = json.loads(raw or b"null")
        except ValueError:
            payload = None
        if not isinstance(payload, dict) or payload.get("decision") not in ("approve", "reject"):
            return problem(request, 422, "invalid-body", "Validation error", "decision must be approve or reject")
        reason = payload.get("reason", "")
        if not isinstance(reason, str) or len(reason) > 500:
            return problem(request, 422, "invalid-body", "Validation error", "reason must be a string of at most 500 characters")
        pol, error = policy_or_503(request)
        if error is not None:
            return error
        decision = pol.decide(principal.role, "shipments", "write", "dispatch")
        if not decision.allowed:
            denial = audit(request, action="ai.decision", principal=principal, resource_type="ai_summary",
                           resource_id=summary_id, rule=decision.rule, decision="deny", outcome="denied")
            if denial is not None:
                return denial
            return problem(request, 403, "policy-denied", "Forbidden", "approver role required")
        if svc.approvals.get_suggestion(summary_id) is None:
            failure = audit(request, action="ai.decision", principal=principal, resource_type="ai_summary",
                            resource_id=summary_id, rule=decision.rule, decision="allow", outcome="error",
                            detail={"reason": "not_found"})
            if failure is not None:
                return failure
            return problem(request, 404, "not-found", "Not found", "no suggestion with that id")
        approval_id = str(uuid.uuid4())
        with svc.approvals.lock():
            if svc.approvals.status(summary_id) != "suggested":
                return problem(request, 409, "already-decided", "Conflict", "the suggestion was already decided")
            failure = audit(request, action="ai.decision", principal=principal, resource_type="ai_summary",
                            resource_id=summary_id, rule=decision.rule, decision="allow", outcome="success",
                            approval_id=approval_id,
                            detail={"decision": payload["decision"]})
            if failure is not None:
                return failure
            try:
                record = svc.approvals.decide(summary_id, payload["decision"], principal.subject,
                                              reason, approval_id=approval_id)
            except (AlreadyDecided, ApprovalError):
                return problem(request, 503, "approval-store-unavailable", "Service unavailable",
                               "the decision could not be stored")
        return JSONResponse({"approval_id": record["approval_id"], "summary_id": summary_id,
                             "decision": record["decision"], "decided_by": record["decided_by"],
                             "decided_at": record["decided_at"]})

    # -- audit verification (FEAT-05) ---------------------------------------
    @app.get("/audit/verify")
    async def verify_audit(request: Request):
        principal, error = authenticate(request)
        if error is not None:
            return error
        if principal.role != "auditor":
            denial = audit(request, action="audit.verify", principal=principal, resource_type="audit",
                           resource_id="chain", rule="platform.auditor_required", decision="deny",
                           outcome="denied")
            if denial is not None:
                return denial
            return problem(request, 403, "policy-denied", "Forbidden", "auditor role required")
        return JSONResponse(svc.audit.verify())

    return app


def _typed(fld: str, raw: str):
    if raw is None or raw == "":
        return None
    if fld in NUMERIC_FIELDS:
        try:
            return float(raw)
        except ValueError:
            return None
    if fld in BOOLEAN_FIELDS:
        return {"true": True, "false": False}.get(raw.strip().lower())
    return raw


# Module-level ASGI object for `uvicorn app.main:app`. load_settings() raises
# ConfigError when APP_ENV is not local and AUTH_SECRET is missing, so the process
# refuses to start.
app = create_app()
