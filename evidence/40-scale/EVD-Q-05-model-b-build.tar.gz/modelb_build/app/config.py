"""Configuration from environment variables only (brief, delivery contract)."""
from __future__ import annotations

import os
import secrets
from dataclasses import dataclass
from pathlib import Path

BUILD_DIR = Path(__file__).resolve().parent.parent
MIN_SECRET_LEN = 32


class ConfigError(RuntimeError):
    """Raised at start-up when configuration is unsafe or incomplete."""


@dataclass(frozen=True)
class Settings:
    app_env: str
    auth_mode: str
    auth_secret: str
    data_dir: Path
    semantic_layer_dir: Path
    audit_path: Path
    approvals_path: Path
    ai_rate_per_minute: int


def load_settings(env=None) -> Settings:
    env = os.environ if env is None else env
    app_env = env.get("APP_ENV", "local").strip() or "local"
    auth_mode = env.get("AUTH_MODE", "hs256").strip().lower()
    if auth_mode not in ("hs256", "jwks"):
        raise ConfigError("AUTH_MODE must be hs256 or jwks")

    secret = env.get("AUTH_SECRET", "")
    if not secret:
        if app_env != "local":
            raise ConfigError("AUTH_SECRET is required when APP_ENV is not local")
        # Local only: an ephemeral secret, so tokens do not survive a restart.
        secret = secrets.token_urlsafe(48)
    if len(secret) < MIN_SECRET_LEN:
        raise ConfigError(f"AUTH_SECRET must be at least {MIN_SECRET_LEN} characters")

    try:
        rate = int(env.get("AI_RATE_PER_MINUTE", "30"))
    except ValueError as exc:
        raise ConfigError("AI_RATE_PER_MINUTE must be an integer") from exc
    if rate < 1:
        raise ConfigError("AI_RATE_PER_MINUTE must be >= 1")

    return Settings(
        app_env=app_env,
        auth_mode=auth_mode,
        auth_secret=secret,
        data_dir=Path(env.get("DATA_DIR") or BUILD_DIR / "data"),
        semantic_layer_dir=Path(env.get("SEMANTIC_LAYER_DIR") or BUILD_DIR / "semantic-layer"),
        audit_path=Path(env.get("AUDIT_PATH") or BUILD_DIR / "var" / "audit.jsonl"),
        approvals_path=Path(env.get("APPROVALS_PATH") or BUILD_DIR / "var" / "approvals.jsonl"),
        ai_rate_per_minute=rate,
    )
